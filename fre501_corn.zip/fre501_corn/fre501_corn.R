# R Code which is used in the FRE501_corn project.

# load the required packages
library(here)
library(tidyverse)
library(lubridate)

# import corn price data and display top rows
corn <- read.csv(here("data","corn_price.csv"))
head(corn)

# change the date from character format to date format
corn_price <- corn %>% 
  mutate(month = mdy(date)) %>%
  select(-date)

# plot the monthly price of corn
ggplot(corn_price,aes(x=month,y=price)) + 
  geom_line() +
  ggtitle("Monthly Corn Futures Price: Jan 2020 - April 2023")


