Please copy most recent version of the data ("corn_price.csv") from Github into this folder before running "fre_501.RMD" in Rstudio.
The Github site is at https://github.com/jvercammen/fre501_corn.